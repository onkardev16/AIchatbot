# ============================================================
# database/db_handler.py
# Handles all SQLite database operations for chat history
# ============================================================

import sqlite3
import os
from datetime import datetime

# Path to the SQLite database file
DB_PATH = os.path.join(os.path.dirname(__file__), "chat_history.db")


def create_connection():
    """
    Create and return a connection to the SQLite database.
    Creates the database file if it doesn't exist.
    """
    try:
        conn = sqlite3.connect(DB_PATH)
        return conn
    except sqlite3.Error as e:
        print(f"[DB ERROR] Could not connect to database: {e}")
        return None


def setup_database():
    """
    Create the chat_history table if it does not already exist.
    Called once at application startup.
    
    Table schema:
        id        - Auto-incremented primary key
        sender    - 'User' or 'Bot'
        message   - The actual message text
        timestamp - Date and time the message was sent
    """
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS chat_history (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender    TEXT    NOT NULL,
                    message   TEXT    NOT NULL,
                    timestamp TEXT    NOT NULL
                )
            """)
            conn.commit()
            print("[DB] Database setup complete.")
        except sqlite3.Error as e:
            print(f"[DB ERROR] Could not create table: {e}")
        finally:
            conn.close()


def save_message(sender: str, message: str):
    """
    Save a single chat message to the database.

    Args:
        sender  (str): Who sent the message — 'User' or 'Bot'
        message (str): The message content
    """
    conn = create_connection()
    if conn:
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO chat_history (sender, message, timestamp) VALUES (?, ?, ?)",
                (sender, message, timestamp)
            )
            conn.commit()
        except sqlite3.Error as e:
            print(f"[DB ERROR] Could not save message: {e}")
        finally:
            conn.close()


def load_chat_history() -> list:
    """
    Retrieve all chat messages from the database, ordered by time.

    Returns:
        list of tuples: [(id, sender, message, timestamp), ...]
    """
    conn = create_connection()
    history = []
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, sender, message, timestamp FROM chat_history ORDER BY id ASC"
            )
            history = cursor.fetchall()
        except sqlite3.Error as e:
            print(f"[DB ERROR] Could not load history: {e}")
        finally:
            conn.close()
    return history


def clear_chat_history():
    """
    Delete all rows from chat_history table (used by Clear Chat button).
    """
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM chat_history")
            conn.commit()
            print("[DB] Chat history cleared.")
        except sqlite3.Error as e:
            print(f"[DB ERROR] Could not clear history: {e}")
        finally:
            conn.close()
