# ============================================================
# gui/chat_window.py
# Main Tkinter GUI — Dark/Light Mode, Typing Animation,
# Voice Input/Output, Chat History via SQLite
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import time
import sys
import os

# ── Add project root to path so imports work ────────────────
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatbot.bot_engine import generate_response
from chatbot.voice_handler import speak, listen
from database.db_handler import setup_database, save_message, load_chat_history, clear_chat_history


# ============================================================
# THEME CONFIGURATION
# Two complete themes: dark and light
# ============================================================
THEMES = {
    "dark": {
        "bg":           "#0F0F1A",   # Very dark navy background
        "sidebar":      "#16213E",   # Sidebar panel
        "chat_bg":      "#1A1A2E",   # Chat area background
        "user_bubble":  "#4A90D9",   # User message bubble
        "bot_bubble":   "#1E3A5F",   # Bot message bubble
        "input_bg":     "#16213E",   # Input field background
        "input_fg":     "#E0E0FF",   # Input text color
        "text_fg":      "#E0E0FF",   # General foreground text
        "muted":        "#6B7280",   # Muted/secondary text
        "accent":       "#4A90D9",   # Accent / highlight color
        "accent2":      "#7C3AED",   # Secondary accent (purple)
        "btn_bg":       "#4A90D9",   # Button background
        "btn_fg":       "#FFFFFF",   # Button text
        "btn_hover":    "#357ABD",   # Button hover
        "danger":       "#EF4444",   # Red for clear/delete
        "success":      "#10B981",   # Green for online status
        "header":       "#0D1B2A",   # Header bar
        "scrollbar":    "#2D3748",   # Scrollbar color
        "border":       "#2D3748",   # Border color
        "timestamp":    "#4B5563",   # Timestamp text color
        "shadow":       "#070712",   # Shadow color
        "toggle_btn":   "☀️  Light Mode",
        "voice_on":     "#10B981",
        "voice_off":    "#6B7280",
    },
    "light": {
        "bg":           "#F0F4F8",
        "sidebar":      "#FFFFFF",
        "chat_bg":      "#FAFBFC",
        "user_bubble":  "#3B82F6",
        "bot_bubble":   "#E8F0FE",
        "input_bg":     "#FFFFFF",
        "input_fg":     "#1F2937",
        "text_fg":      "#1F2937",
        "muted":        "#6B7280",
        "accent":       "#3B82F6",
        "accent2":      "#7C3AED",
        "btn_bg":       "#3B82F6",
        "btn_fg":       "#FFFFFF",
        "btn_hover":    "#2563EB",
        "danger":       "#EF4444",
        "success":      "#10B981",
        "header":       "#1E3A5F",
        "scrollbar":    "#CBD5E1",
        "border":       "#E2E8F0",
        "timestamp":    "#9CA3AF",
        "shadow":       "#CBD5E1",
        "toggle_btn":   "🌙  Dark Mode",
        "voice_on":     "#10B981",
        "voice_off":    "#9CA3AF",
    }
}


# ============================================================
# CHAT APPLICATION CLASS
# ============================================================
class ChatApplication:
    """
    Main application class for the AI Chatbot GUI.
    Handles all widgets, events, and state management.
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("EduBot — AI Chatbot 🤖")
        self.root.geometry("900x700")
        self.root.minsize(700, 550)

        # ── App State ──────────────────────────────────────
        self.current_theme = "dark"           # Start in dark mode
        self.theme = THEMES[self.current_theme]
        self.voice_enabled = tk.BooleanVar(value=False)   # Voice output toggle
        self.is_typing = False                # Typing animation flag
        self.message_count = 0               # Track message number

        # ── Database setup ─────────────────────────────────
        setup_database()

        # ── Build UI ───────────────────────────────────────
        self._build_ui()
        self._apply_theme()
        self._load_history()
        self._show_welcome()

        # ── Window close handler ───────────────────────────
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.bind("<Configure>", self._on_resize)

    # ──────────────────────────────────────────────────────
    # UI CONSTRUCTION
    # ──────────────────────────────────────────────────────

    def _build_ui(self):
        """Construct all widgets and layout."""
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        # ── Main container ─────────────────────────────────
        self.main_frame = tk.Frame(self.root)
        self.main_frame.grid(row=0, column=0, sticky="nsew")
        self.main_frame.grid_rowconfigure(1, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

        # ── Header bar ─────────────────────────────────────
        self._build_header()

        # ── Chat + Sidebar layout ──────────────────────────
        self.content_frame = tk.Frame(self.main_frame)
        self.content_frame.grid(row=1, column=0, sticky="nsew")
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(1, weight=0)

        # Chat area (left, expands)
        self._build_chat_area()

        # Sidebar (right, fixed width)
        self._build_sidebar()

        # ── Input bar ──────────────────────────────────────
        self._build_input_bar()

        # ── Status bar ─────────────────────────────────────
        self._build_status_bar()

    def _build_header(self):
        """Top header: logo, title, theme toggle."""
        self.header = tk.Frame(self.main_frame, height=60)
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.grid_propagate(False)

        # Left: logo + title
        left = tk.Frame(self.header)
        left.pack(side="left", padx=16, pady=8)

        self.lbl_logo = tk.Label(left, text="🤖", font=("Segoe UI Emoji", 22))
        self.lbl_logo.pack(side="left")

        title_frame = tk.Frame(left)
        title_frame.pack(side="left", padx=8)

        self.lbl_title = tk.Label(
            title_frame, text="EduBot",
            font=("Segoe UI", 16, "bold")
        )
        self.lbl_title.pack(anchor="w")

        self.lbl_subtitle = tk.Label(
            title_frame, text="AI College Assistant",
            font=("Segoe UI", 9)
        )
        self.lbl_subtitle.pack(anchor="w")

        # Right: status dot + theme toggle
        right = tk.Frame(self.header)
        right.pack(side="right", padx=16, pady=8)

        # Online status
        self.lbl_status_dot = tk.Label(right, text="●", font=("Segoe UI", 12))
        self.lbl_status_dot.pack(side="left")
        self.lbl_online = tk.Label(right, text="Online", font=("Segoe UI", 9))
        self.lbl_online.pack(side="left", padx=(2, 16))

        # Theme toggle button
        self.btn_theme = tk.Button(
            right, text="☀️  Light Mode",
            font=("Segoe UI", 9), relief="flat",
            cursor="hand2", padx=10, pady=4,
            command=self._toggle_theme
        )
        self.btn_theme.pack(side="left")

    def _build_chat_area(self):
        """Scrollable chat display area."""
        chat_container = tk.Frame(self.content_frame)
        chat_container.grid(row=0, column=0, sticky="nsew")
        chat_container.grid_rowconfigure(0, weight=1)
        chat_container.grid_columnconfigure(0, weight=1)

        # Canvas for custom scrolling
        self.canvas = tk.Canvas(chat_container, highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")

        # Scrollbar
        self.scrollbar = tk.Scrollbar(
            chat_container, orient="vertical",
            command=self.canvas.yview
        )
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # Frame inside canvas that holds all messages
        self.messages_frame = tk.Frame(self.canvas)
        self.canvas_window = self.canvas.create_window(
            (0, 0), window=self.messages_frame, anchor="nw"
        )

        # Bind resize events
        self.messages_frame.bind("<Configure>", self._on_frame_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _build_sidebar(self):
        """Right sidebar with quick-action buttons."""
        self.sidebar = tk.Frame(self.content_frame, width=180)
        self.sidebar.grid(row=0, column=1, sticky="ns", padx=(0, 0))
        self.sidebar.grid_propagate(False)

        # Title
        tk.Label(
            self.sidebar, text="Quick Actions",
            font=("Segoe UI", 10, "bold")
        ).pack(pady=(16, 8), padx=8)

        # Separator
        ttk.Separator(self.sidebar, orient="horizontal").pack(fill="x", padx=8)

        # Quick-reply buttons
        quick_topics = [
            ("📚  Courses",     "Tell me about courses"),
            ("📋  Admissions",  "How do I apply for admission?"),
            ("📅  Exams",       "When are the exams?"),
            ("💼  Placement",   "Tell me about placement"),
            ("🏠  Hostel",      "Tell me about hostel"),
            ("💰  Fees",        "What are the fees?"),
            ("🕐  Time",        "What time is it?"),
            ("😂  Joke",        "Tell me a joke"),
            ("💪  Motivate",    "Give me motivation"),
            ("❓  Help",        "help"),
        ]

        self.quick_buttons = []
        for label, query in quick_topics:
            btn = tk.Button(
                self.sidebar, text=label,
                font=("Segoe UI", 9), relief="flat",
                anchor="w", cursor="hand2",
                padx=10, pady=5,
                command=lambda q=query: self._quick_send(q)
            )
            btn.pack(fill="x", padx=8, pady=2)
            self.quick_buttons.append(btn)

        # Spacer
        tk.Frame(self.sidebar).pack(expand=True, fill="both")

        # Voice toggle
        ttk.Separator(self.sidebar, orient="horizontal").pack(fill="x", padx=8)
        self.chk_voice = tk.Checkbutton(
            self.sidebar, text="🔊 Voice Output",
            variable=self.voice_enabled,
            font=("Segoe UI", 9),
            cursor="hand2"
        )
        self.chk_voice.pack(pady=8, padx=8, anchor="w")

    def _build_input_bar(self):
        """Bottom input area: text entry + send + mic buttons."""
        self.input_frame = tk.Frame(self.main_frame, height=70)
        self.input_frame.grid(row=2, column=0, sticky="ew")
        self.input_frame.grid_propagate(False)
        self.input_frame.grid_columnconfigure(0, weight=1)

        # Inner padding frame
        inner = tk.Frame(self.input_frame)
        inner.pack(fill="both", expand=True, padx=12, pady=10)
        inner.grid_columnconfigure(0, weight=1)

        # Text entry field
        self.input_entry = tk.Entry(
            inner, font=("Segoe UI", 12),
            relief="flat", bd=0
        )
        self.input_entry.grid(row=0, column=0, sticky="ew", ipady=8, padx=(8, 0))

        # Bind Enter key to send
        self.input_entry.bind("<Return>", lambda e: self._send_message())
        self.input_entry.bind("<KeyRelease>", self._on_typing)

        # Mic button (voice input)
        self.btn_mic = tk.Button(
            inner, text="🎙️", font=("Segoe UI Emoji", 14),
            relief="flat", cursor="hand2",
            padx=8, pady=4,
            command=self._voice_input
        )
        self.btn_mic.grid(row=0, column=1, padx=4)

        # Send button
        self.btn_send = tk.Button(
            inner, text="Send  ➤",
            font=("Segoe UI", 10, "bold"),
            relief="flat", cursor="hand2",
            padx=14, pady=6,
            command=self._send_message
        )
        self.btn_send.grid(row=0, column=2, padx=(0, 4))

        # Input border decoration (drawn as a frame outline)
        self.input_border = tk.Frame(inner, height=2)
        self.input_border.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(4, 0))

    def _build_status_bar(self):
        """Bottom status bar showing character count and session info."""
        self.status_bar = tk.Frame(self.main_frame, height=24)
        self.status_bar.grid(row=3, column=0, sticky="ew")

        self.lbl_char_count = tk.Label(
            self.status_bar, text="",
            font=("Segoe UI", 8)
        )
        self.lbl_char_count.pack(side="right", padx=12)

        self.lbl_session = tk.Label(
            self.status_bar,
            text="💬 Session active  |  Type 'help' for options",
            font=("Segoe UI", 8)
        )
        self.lbl_session.pack(side="left", padx=12)

    # ──────────────────────────────────────────────────────
    # THEME ENGINE
    # ──────────────────────────────────────────────────────

    def _apply_theme(self):
        """Apply the current theme colors to all widgets."""
        t = self.theme

        # Root and main frames
        self.root.configure(bg=t["bg"])
        self.main_frame.configure(bg=t["bg"])
        self.content_frame.configure(bg=t["bg"])

        # Header
        self.header.configure(bg=t["header"])
        for w in [self.lbl_logo, self.lbl_title, self.lbl_subtitle]:
            w.configure(bg=t["header"], fg=t["text_fg"])
        self.lbl_subtitle.configure(fg=t["muted"])
        self.lbl_status_dot.configure(bg=t["header"], fg=t["success"])
        self.lbl_online.configure(bg=t["header"], fg=t["success"])
        self.btn_theme.configure(
            bg=t["btn_bg"], fg=t["btn_fg"],
            activebackground=t["btn_hover"],
            activeforeground=t["btn_fg"],
            text=t["toggle_btn"]
        )

        # Chat area
        self.canvas.configure(bg=t["chat_bg"])
        self.messages_frame.configure(bg=t["chat_bg"])
        self.scrollbar.configure(bg=t["scrollbar"])

        # Sidebar
        self.sidebar.configure(bg=t["sidebar"])
        for w in self.sidebar.winfo_children():
            if isinstance(w, tk.Label):
                w.configure(bg=t["sidebar"], fg=t["text_fg"])
            elif isinstance(w, tk.Frame):
                w.configure(bg=t["sidebar"])
        for btn in self.quick_buttons:
            btn.configure(
                bg=t["sidebar"], fg=t["text_fg"],
                activebackground=t["accent"],
                activeforeground="#FFFFFF"
            )
        self.chk_voice.configure(
            bg=t["sidebar"], fg=t["text_fg"],
            activebackground=t["sidebar"],
            selectcolor=t["accent"]
        )

        # Input bar
        self.input_frame.configure(bg=t["input_bg"])
        for w in self.input_frame.winfo_children():
            if isinstance(w, tk.Frame):
                w.configure(bg=t["input_bg"])
        self.input_entry.configure(
            bg=t["input_bg"], fg=t["input_fg"],
            insertbackground=t["accent"],
            disabledbackground=t["input_bg"]
        )
        self.btn_mic.configure(
            bg=t["input_bg"], fg=t["text_fg"],
            activebackground=t["accent"],
            activeforeground="#FFFFFF"
        )
        self.btn_send.configure(
            bg=t["btn_bg"], fg=t["btn_fg"],
            activebackground=t["btn_hover"],
            activeforeground=t["btn_fg"]
        )
        self.input_border.configure(bg=t["accent"])

        # Status bar
        self.status_bar.configure(bg=t["bg"])
        self.lbl_session.configure(bg=t["bg"], fg=t["muted"])
        self.lbl_char_count.configure(bg=t["bg"], fg=t["muted"])

    def _toggle_theme(self):
        """Switch between dark and light themes."""
        self.current_theme = "light" if self.current_theme == "dark" else "dark"
        self.theme = THEMES[self.current_theme]
        self._apply_theme()
        self._rerender_messages()

    # ──────────────────────────────────────────────────────
    # MESSAGE RENDERING
    # ──────────────────────────────────────────────────────

    def _add_message(self, sender: str, text: str, animate: bool = False):
        """
        Add a message bubble to the chat display.

        Args:
            sender  (str):  'User' or 'Bot'
            text    (str):  Message content
            animate (bool): If True, use typing animation for bot messages
        """
        t = self.theme
        is_user = sender == "User"

        # ── Outer row frame ────────────────────────────────
        row = tk.Frame(self.messages_frame, bg=t["chat_bg"])
        row.pack(fill="x", padx=12, pady=4)

        # ── Avatar ─────────────────────────────────────────
        avatar_text = "🧑" if is_user else "🤖"
        avatar = tk.Label(
            row, text=avatar_text,
            font=("Segoe UI Emoji", 16),
            bg=t["chat_bg"]
        )

        # ── Bubble frame ───────────────────────────────────
        bubble_color = t["user_bubble"] if is_user else t["bot_bubble"]
        bubble_fg    = "#FFFFFF" if is_user else t["text_fg"]

        bubble = tk.Frame(row, bg=bubble_color, padx=12, pady=8)

        # Sender label
        sender_label = tk.Label(
            bubble,
            text="You" if is_user else "EduBot",
            font=("Segoe UI", 8, "bold"),
            bg=bubble_color,
            fg="#FFFFFF" if is_user else t["accent"]
        )
        sender_label.pack(anchor="w")

        # Message text widget (read-only, auto-wraps)
        msg_text = tk.Text(
            bubble,
            font=("Segoe UI", 10),
            bg=bubble_color, fg=bubble_fg,
            relief="flat", bd=0,
            wrap="word",
            cursor="arrow",
            state="normal",
            height=1
        )
        msg_text.pack(anchor="w", fill="x")

        # Timestamp
        from datetime import datetime
        ts = datetime.now().strftime("%I:%M %p")
        ts_label = tk.Label(
            bubble, text=ts,
            font=("Segoe UI", 7),
            bg=bubble_color,
            fg="#CCCCCC" if is_user else t["timestamp"]
        )
        ts_label.pack(anchor="e")

        # ── Layout: user right, bot left ───────────────────
        if is_user:
            bubble.pack(side="right", anchor="e")
            avatar.pack(side="right", padx=(4, 0))
        else:
            avatar.pack(side="left", padx=(0, 4))
            bubble.pack(side="left", anchor="w")

        # ── Insert text (with optional typing animation) ───
        if animate and not is_user:
            self._animate_typing(msg_text, text, bubble_color)
        else:
            msg_text.insert("1.0", text)
            self._resize_text_widget(msg_text)
            msg_text.configure(state="disabled")

        # Scroll to bottom
        self.root.after(50, self._scroll_to_bottom)
        self.message_count += 1

    def _animate_typing(self, text_widget: tk.Text, full_text: str, bg_color: str):
        """
        Simulate a typing effect — reveals text character by character.

        Args:
            text_widget (tk.Text): The text widget to animate
            full_text   (str):     Complete message to type out
            bg_color    (str):     Background color of the bubble
        """
        self.is_typing = True
        idx = 0

        def type_next():
            nonlocal idx
            if idx < len(full_text):
                text_widget.configure(state="normal")
                text_widget.insert("end", full_text[idx])
                self._resize_text_widget(text_widget)
                text_widget.configure(state="disabled")
                self._scroll_to_bottom()
                idx += 1
                # Speed: ~25ms per character (adjust for faster/slower)
                delay = 15 if full_text[idx-1] == " " else 20
                self.root.after(delay, type_next)
            else:
                self.is_typing = False

        type_next()

    def _resize_text_widget(self, text_widget: tk.Text):
        """Auto-resize text widget height based on content lines."""
        text_widget.update_idletasks()
        lines = int(text_widget.index("end-1c").split(".")[0])
        # Clamp between 1 and 20 lines
        text_widget.configure(height=min(max(lines, 1), 20))

    def _rerender_messages(self):
        """
        Clear and re-draw all messages (used when theme switches).
        Reloads history from the database.
        """
        for widget in self.messages_frame.winfo_children():
            widget.destroy()
        self._load_history()

    # ──────────────────────────────────────────────────────
    # CHAT LOGIC
    # ──────────────────────────────────────────────────────

    def _send_message(self):
        """
        Handle sending a user message:
        1. Read input
        2. Display user bubble
        3. Save to DB
        4. Show typing indicator
        5. Generate bot response in background thread
        6. Display bot response with animation
        """
        user_text = self.input_entry.get().strip()
        if not user_text:
            return

        # Clear input field
        self.input_entry.delete(0, "end")
        self.lbl_char_count.configure(text="")

        # Show user message
        self._add_message("User", user_text)
        save_message("User", user_text)

        # Check for quit commands
        if user_text.lower() in ["quit", "exit", "bye", "goodbye"]:
            self.root.after(800, self._graceful_exit)
            return

        # Show "EduBot is typing..." indicator
        typing_frame = self._show_typing_indicator()

        # Generate response in background (prevents GUI freeze)
        def get_response():
            try:
                response = generate_response(user_text)
            except Exception as e:
                response = f"⚠️ Oops! Something went wrong: {e}"

            # Update GUI from main thread
            self.root.after(600, lambda: self._display_bot_response(
                response, typing_frame
            ))

        threading.Thread(target=get_response, daemon=True).start()

    def _display_bot_response(self, response: str, typing_frame):
        """Remove typing indicator and show bot response."""
        # Remove typing indicator
        if typing_frame and typing_frame.winfo_exists():
            typing_frame.destroy()

        self._add_message("Bot", response, animate=True)
        save_message("Bot", response)

        # Speak response if voice is enabled
        if self.voice_enabled.get():
            speak(response, enabled=True)

    def _show_typing_indicator(self) -> tk.Frame:
        """
        Display an animated '...' indicator while bot is thinking.

        Returns:
            tk.Frame: The indicator frame (to destroy later)
        """
        t = self.theme
        frame = tk.Frame(self.messages_frame, bg=t["chat_bg"])
        frame.pack(fill="x", padx=12, pady=4)

        tk.Label(
            frame, text="🤖",
            font=("Segoe UI Emoji", 16),
            bg=t["chat_bg"]
        ).pack(side="left", padx=(0, 4))

        bubble = tk.Frame(frame, bg=t["bot_bubble"], padx=12, pady=8)
        bubble.pack(side="left")

        self.typing_dots = tk.Label(
            bubble, text="●  ●  ●",
            font=("Segoe UI", 12),
            bg=t["bot_bubble"],
            fg=t["muted"]
        )
        self.typing_dots.pack()

        # Animate the dots
        self._animate_dots(self.typing_dots, t["bot_bubble"], t["muted"])

        self._scroll_to_bottom()
        return frame

    def _animate_dots(self, label: tk.Label, bg: str, fg: str, step: int = 0):
        """Cycle through dot patterns to show activity."""
        if not label.winfo_exists():
            return
        patterns = ["●  ○  ○", "●  ●  ○", "●  ●  ●", "○  ●  ●", "○  ○  ●"]
        label.configure(text=patterns[step % len(patterns)])
        self.root.after(300, lambda: self._animate_dots(label, bg, fg, step + 1))

    def _quick_send(self, query: str):
        """Send a quick-action button query as if the user typed it."""
        self.input_entry.delete(0, "end")
        self.input_entry.insert(0, query)
        self._send_message()

    def _voice_input(self):
        """Start listening for voice input in a background thread."""
        self.btn_mic.configure(text="🔴", state="disabled")
        self.lbl_session.configure(text="🎙️ Listening... Speak now!")

        def listen_thread():
            result = listen()
            self.root.after(0, lambda: self._handle_voice_result(result))

        threading.Thread(target=listen_thread, daemon=True).start()

    def _handle_voice_result(self, result: str):
        """Handle the result of voice recognition."""
        self.btn_mic.configure(text="🎙️", state="normal")
        self.lbl_session.configure(text="💬 Session active  |  Type 'help' for options")

        if result.startswith("[ERROR]"):
            self._add_message("Bot", f"⚠️ Voice Error:\n{result[7:]}")
        else:
            self.input_entry.insert(0, result)
            self._send_message()

    # ──────────────────────────────────────────────────────
    # HISTORY & WELCOME
    # ──────────────────────────────────────────────────────

    def _load_history(self):
        """Load previous chat messages from the SQLite database."""
        history = load_chat_history()
        if history:
            # Show a divider before old messages
            self._add_divider("── Previous Session ──")
            for _, sender, message, _ in history:
                self._add_message(sender, message)
            self._add_divider("── Current Session ──")

    def _show_welcome(self):
        """Show a welcome message from the bot on startup."""
        welcome = (
            "👋 Hello! I'm **EduBot** — your AI college assistant!\n\n"
            "I can help you with:\n"
            "• 🎓 College info (admissions, courses, exams, placement)\n"
            "• 🕐 Time & date queries\n"
            "• 💻 Coding & technology questions\n"
            "• 😂 Jokes and motivation!\n\n"
            "Type your question or click a quick-action button. Type 'help' for all options!"
        )
        self._add_message("Bot", welcome, animate=True)

    def _add_divider(self, text: str):
        """Add a visual divider label between message groups."""
        t = self.theme
        frame = tk.Frame(self.messages_frame, bg=t["chat_bg"])
        frame.pack(fill="x", padx=24, pady=8)
        tk.Label(
            frame, text=text,
            font=("Segoe UI", 8),
            fg=t["muted"], bg=t["chat_bg"]
        ).pack()

    # ──────────────────────────────────────────────────────
    # CONTROLS (Clear, Close)
    # ──────────────────────────────────────────────────────

    def _clear_chat(self):
        """Clear all messages from the display and database."""
        if messagebox.askyesno(
            "Clear Chat",
            "Are you sure you want to clear all chat history?\nThis cannot be undone."
        ):
            # Remove all message widgets
            for widget in self.messages_frame.winfo_children():
                widget.destroy()
            # Clear database
            clear_chat_history()
            # Show confirmation
            self._add_message("Bot", "🗑️ Chat history cleared. Starting fresh! 😊")

    def _graceful_exit(self):
        """Say goodbye before closing."""
        self._add_message("Bot", "Goodbye! 👋 Have a great day! See you soon! 🌟")
        self.root.after(1500, self.root.destroy)

    def _on_close(self):
        """Handle window close button."""
        if messagebox.askokcancel("Exit", "Are you sure you want to exit EduBot?"):
            self.root.destroy()

    # ──────────────────────────────────────────────────────
    # SCROLL & RESIZE HELPERS
    # ──────────────────────────────────────────────────────

    def _scroll_to_bottom(self):
        """Scroll chat to the most recent message."""
        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def _on_frame_configure(self, event=None):
        """Update scroll region when message frame resizes."""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event=None):
        """Keep message frame width equal to canvas width."""
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def _on_mousewheel(self, event):
        """Handle mouse scroll wheel."""
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_resize(self, event=None):
        """Handle window resize — update scrollregion."""
        self.root.after(10, self._on_frame_configure)

    def _on_typing(self, event=None):
        """Update character counter as user types."""
        text = self.input_entry.get()
        count = len(text)
        if count > 0:
            color = "#EF4444" if count > 200 else self.theme["muted"]
            self.lbl_char_count.configure(text=f"{count}/500 chars", fg=color)
        else:
            self.lbl_char_count.configure(text="")


# ============================================================
# MAIN ENTRY POINT
# ============================================================
def run_app():
    """Initialize and launch the Tkinter application."""
    root = tk.Tk()

    # Try to set app icon (optional)
    try:
        root.iconbitmap("assets/icon.ico")
    except Exception:
        pass

    app = ChatApplication(root)
    root.mainloop()


if __name__ == "__main__":
    run_app()
