# ============================================================
# chatbot/voice_handler.py
# Handles Text-to-Speech (TTS) and Speech-to-Text (STT)
# Uses pyttsx3 for TTS and SpeechRecognition for STT
# ============================================================

import threading


# ── Text-to-Speech ───────────────────────────────────────────
def speak(text: str, enabled: bool = True):
    """
    Convert text to speech using pyttsx3.
    Runs in a background thread to avoid freezing the GUI.

    Args:
        text    (str):  The text to speak
        enabled (bool): If False, TTS is skipped (voice off)
    """
    if not enabled:
        return

    def _speak():
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty("rate", 160)    # Speaking speed
            engine.setProperty("volume", 0.9)  # Volume (0.0 – 1.0)

            # Try to use a female voice if available
            voices = engine.getProperty("voices")
            for voice in voices:
                if "female" in voice.name.lower() or "zira" in voice.name.lower():
                    engine.setProperty("voice", voice.id)
                    break

            # Strip markdown-style bold markers before speaking
            clean_text = text.replace("**", "").replace("*", "")
            engine.say(clean_text)
            engine.runAndWait()
        except ImportError:
            print("[VOICE] pyttsx3 not installed. Run: pip install pyttsx3")
        except Exception as e:
            print(f"[VOICE TTS ERROR] {e}")

    # Run TTS in a daemon thread (won't block GUI)
    t = threading.Thread(target=_speak, daemon=True)
    t.start()


# ── Speech-to-Text ───────────────────────────────────────────
def listen() -> str:
    """
    Capture audio from the microphone and convert to text.
    Uses Google Web Speech API (requires internet).

    Returns:
        str: Recognized text, or an error message string starting with '[ERROR]'
    """
    try:
        import speech_recognition as sr

        recognizer = sr.Recognizer()
        recognizer.pause_threshold = 1.0   # Seconds of silence to mark end

        with sr.Microphone() as source:
            print("[VOICE] Adjusting for ambient noise...")
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            print("[VOICE] Listening...")
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)

        text = recognizer.recognize_google(audio)
        print(f"[VOICE] Recognized: {text}")
        return text

    except ImportError:
        return "[ERROR] SpeechRecognition not installed. Run: pip install SpeechRecognition"
    except Exception as e:
        name = type(e).__name__
        if "WaitTimeoutError" in name:
            return "[ERROR] No speech detected. Please try again."
        elif "UnknownValueError" in name:
            return "[ERROR] Could not understand audio. Please speak clearly."
        elif "RequestError" in name:
            return "[ERROR] Internet connection required for voice input."
        else:
            return f"[ERROR] Voice error: {e}"
