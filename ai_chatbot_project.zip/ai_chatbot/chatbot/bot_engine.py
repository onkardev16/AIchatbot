# ============================================================
# chatbot/bot_engine.py
# Core chatbot logic using NLTK for NLP processing
# Handles pattern matching, tokenization, and response generation
# ============================================================

import random
import re
from datetime import datetime

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# ── NLTK data download (runs once) ──────────────────────────
def download_nltk_data():
    """Download required NLTK datasets silently on first run."""
    packages = ["punkt", "stopwords", "wordnet", "averaged_perceptron_tagger",
                "punkt_tab", "omw-1.4"]
    for pkg in packages:
        try:
            nltk.download(pkg, quiet=True)
        except Exception as e:
            print(f"[NLTK] Could not download '{pkg}': {e}")

download_nltk_data()

# ── Lemmatizer and Stopwords ─────────────────────────────────
lemmatizer = WordNetLemmatizer()

try:
    stop_words = set(stopwords.words("english"))
except LookupError:
    stop_words = set()


# ============================================================
# INTENTS — A dictionary of patterns and responses
# Each key is an intent name.
# "patterns"  : list of keywords/phrases to match
# "responses" : list of possible bot replies (one picked at random)
# ============================================================
INTENTS = {

    # ── Greetings ──────────────────────────────────────────
    "greeting": {
        "patterns": ["hello", "hi", "hey", "good morning", "good evening",
                     "good afternoon", "what's up", "howdy", "greetings", "sup"],
        "responses": [
            "Hello! 👋 How can I help you today?",
            "Hi there! 😊 What's on your mind?",
            "Hey! Great to see you. How can I assist?",
            "Good day! I'm ready to chat. What do you need?",
        ]
    },

    # ── Farewell ───────────────────────────────────────────
    "farewell": {
        "patterns": ["bye", "goodbye", "see you", "later", "take care",
                     "quit", "exit", "cya", "farewell", "good night"],
        "responses": [
            "Goodbye! 👋 Have a wonderful day!",
            "See you later! Take care 😊",
            "Bye! Come back anytime you need help.",
            "Farewell! It was great talking to you. 🌟",
        ]
    },

    # ── Thanks ─────────────────────────────────────────────
    "thanks": {
        "patterns": ["thank", "thanks", "thank you", "thx", "ty",
                     "appreciate", "helpful", "great help", "well done"],
        "responses": [
            "You're welcome! 😊",
            "Happy to help! Anything else?",
            "Anytime! That's what I'm here for. 🤖",
            "Glad I could assist! Let me know if you need more help.",
        ]
    },

    # ── Bot Identity ───────────────────────────────────────
    "identity": {
        "patterns": ["who are you", "what are you", "your name", "introduce yourself",
                     "about yourself", "what can you do", "are you a bot",
                     "are you human", "are you ai", "are you robot"],
        "responses": [
            "I'm EduBot 🤖 — an AI chatbot built with Python, NLTK, and Tkinter!\n"
            "I can answer general questions, college-related queries, tell you the time, and more.",
            "I'm EduBot, your smart college assistant! 🎓\n"
            "I was created using Python + NLTK for NLP and Tkinter for my GUI.",
            "Hi! I'm EduBot 🤖 — designed to help students with everyday questions.\n"
            "Ask me about time, courses, exams, or just have a chat!",
        ]
    },

    # ── How are you ────────────────────────────────────────
    "how_are_you": {
        "patterns": ["how are you", "how do you do", "how's it going",
                     "are you okay", "you good", "you alright", "feeling"],
        "responses": [
            "I'm doing great, thanks for asking! 😄 How about you?",
            "Running perfectly! All circuits nominal 🤖 How are you?",
            "I'm wonderful! Ready to help you with anything. 🌟",
            "Fantastic! I never have a bad day 😊 How can I help?",
        ]
    },

    # ── Time ───────────────────────────────────────────────
    "time": {
        "patterns": ["time", "what time", "current time", "tell me the time",
                     "what's the time", "clock"],
        "responses": ["__TIME__"]   # Special placeholder — replaced at runtime
    },

    # ── Date ───────────────────────────────────────────────
    "date": {
        "patterns": ["date", "today", "what day", "current date",
                     "what's today", "day is it", "month", "year"],
        "responses": ["__DATE__"]   # Special placeholder — replaced at runtime
    },

    # ── College — Admissions ───────────────────────────────
    "admissions": {
        "patterns": ["admission", "apply", "enrollment", "register",
                     "join college", "how to apply", "application form",
                     "admission process", "eligibility"],
        "responses": [
            "📋 **Admission Process:**\n"
            "1. Visit the official college website.\n"
            "2. Fill out the online application form.\n"
            "3. Upload required documents (marksheets, ID proof).\n"
            "4. Pay the application fee.\n"
            "5. Await confirmation via email.\n"
            "Contact the admission office for specific cut-offs.",

            "🎓 **How to Apply:**\n"
            "• Check eligibility criteria on the college portal.\n"
            "• Submit your 10th & 12th marksheets.\n"
            "• Attend the entrance test if required.\n"
            "• Merit-based or entrance-based admission varies by branch.",
        ]
    },

    # ── College — Courses ──────────────────────────────────
    "courses": {
        "patterns": ["course", "branch", "subject", "department",
                     "what courses", "available courses", "engineering branches",
                     "cse", "computer science", "mechanical", "civil", "electrical",
                     "it", "information technology", "program", "curriculum",
                     "about courses", "courses offered"],
        "responses": [
            "📚 **Available Engineering Branches:**\n"
            "• Computer Science Engineering (CSE)\n"
            "• Information Technology (IT)\n"
            "• Mechanical Engineering (ME)\n"
            "• Civil Engineering (CE)\n"
            "• Electrical Engineering (EE)\n"
            "• Electronics & Telecommunication (EXTC)\n"
            "Each branch has a 4-year B.E./B.Tech program.",

            "🖥️ **CSE Subjects (Sample):**\n"
            "• Data Structures & Algorithms\n"
            "• Operating Systems\n"
            "• Database Management Systems\n"
            "• Computer Networks\n"
            "• Artificial Intelligence & Machine Learning",
        ]
    },

    # ── College — Exams ────────────────────────────────────
    "exams": {
        "patterns": ["exam", "test", "timetable", "schedule", "semester",
                     "result", "marks", "grade", "pass", "fail", "backlog",
                     "internal", "external", "practical"],
        "responses": [
            "📅 **Exam Schedule Tips:**\n"
            "• Check the official college notice board or website.\n"
            "• Semester exams are usually held in Nov-Dec & Apr-May.\n"
            "• Internal assessments are conducted by your department.\n"
            "• Hall tickets are issued 1 week before the exam.",

            "📝 **Exam Preparation Tips:**\n"
            "• Start early — don't cram the night before!\n"
            "• Refer to previous year question papers.\n"
            "• Make short notes for each subject.\n"
            "• Join study groups for difficult topics.",
        ]
    },

    # ── College — Fees ─────────────────────────────────────
    "fees": {
        "patterns": ["fee", "fees", "tuition fee", "tuition cost",
                     "college fees", "course fee", "scholarship",
                     "fee structure", "how much fees", "payment", "installment",
                     "total fees", "annual fee"],
        "responses": [
            "💰 **Fee Structure:**\n"
            "Fees vary by branch and year of admission.\n"
            "• Tuition Fee: ₹60,000 – ₹1,20,000/year (approx.)\n"
            "• Hostel Fee: ₹40,000 – ₹80,000/year (approx.)\n"
            "• Scholarships available for EBC, OBC, SC/ST categories.\n"
            "Contact the accounts office for exact figures.",
        ]
    },

    # ── College — Library ──────────────────────────────────
    "library": {
        "patterns": ["library", "book", "borrow", "return book", "e-library",
                     "issue book", "reading room"],
        "responses": [
            "📖 **Library Info:**\n"
            "• Open: Mon–Sat, 8 AM – 8 PM\n"
            "• Students can borrow up to 3 books at a time.\n"
            "• E-library access available via college portal.\n"
            "• Late return fine: ₹2/day per book.",
        ]
    },

    # ── College — Placement ────────────────────────────────
    "placement": {
        "patterns": ["placement", "job", "internship", "recruit", "company",
                     "campus drive", "package", "salary", "career"],
        "responses": [
            "💼 **Placement Cell:**\n"
            "• Top recruiters: TCS, Infosys, Wipro, Cognizant, Capgemini.\n"
            "• Average package: ₹3.5 – ₹6 LPA\n"
            "• Highest package: ₹18+ LPA\n"
            "• Register on the placement portal before drives.",

            "🚀 **Internship Tips:**\n"
            "• Apply on LinkedIn, Internshala, and Naukri.\n"
            "• Prepare your resume and GitHub profile.\n"
            "• Practice DSA for tech companies.",
        ]
    },

    # ── College — Hostel ───────────────────────────────────
    "hostel": {
        "patterns": ["hostel", "dormitory", "accommodation", "hostel room",
                     "hostel facilities", "hostel fee", "boys hostel", "girls hostel",
                     "mess food", "hostel mess", "stay on campus", "pg accommodation"],
        "responses": [
            "🏠 **Hostel Facilities:**\n"
            "• Separate hostels for boys and girls.\n"
            "• 24/7 security and CCTV surveillance.\n"
            "• Wi-Fi enabled rooms.\n"
            "• Mess provides 3 meals a day.\n"
            "Apply through the college hostel portal.",
        ]
    },

    # ── Python / Programming ───────────────────────────────
    "python": {
        "patterns": ["python", "programming", "code", "coding", "developer",
                     "software", "language", "algorithm", "data structure"],
        "responses": [
            "🐍 **Python Tips:**\n"
            "• Python is great for beginners — simple, readable syntax.\n"
            "• Use libraries like NumPy, Pandas, Matplotlib for data science.\n"
            "• Django/Flask for web development.\n"
            "• This chatbot itself is built in Python! 😄",

            "💻 **Learning Resources:**\n"
            "• Python.org official docs\n"
            "• freeCodeCamp Python Course (YouTube)\n"
            "• GeeksforGeeks, W3Schools\n"
            "• Practice on HackerRank & LeetCode",
        ]
    },

    # ── AI / ML ────────────────────────────────────────────
    "ai_ml": {
        "patterns": ["artificial intelligence", "machine learning", "deep learning",
                     "neural network", "nlp", "natural language processing",
                     "chatbot", "ai", "ml", "data science"],
        "responses": [
            "🤖 **AI & ML Overview:**\n"
            "• AI = making machines simulate human intelligence.\n"
            "• ML = systems that learn from data without explicit programming.\n"
            "• NLP = understanding human language (used in this chatbot!).\n"
            "• Popular tools: TensorFlow, PyTorch, Scikit-learn, NLTK.",
        ]
    },

    # ── Jokes ──────────────────────────────────────────────
    "joke": {
        "patterns": ["joke", "funny", "laugh", "humor", "make me laugh",
                     "something funny", "crack a joke"],
        "responses": [
            "😂 Why do programmers prefer dark mode?\nBecause light attracts bugs!",
            "🤣 How many programmers does it take to change a light bulb?\nNone — that's a hardware problem!",
            "😄 Why did the student eat his homework?\nBecause the teacher told him it was a piece of cake!",
            "😆 A SQL query walks into a bar, walks up to two tables and asks...\n'Can I join you?'",
        ]
    },

    # ── Motivational ───────────────────────────────────────
    "motivation": {
        "patterns": ["motivate", "motivation", "inspire", "sad", "depressed",
                     "stressed", "tired", "give up", "quote", "encourage"],
        "responses": [
            "💪 \"The secret of getting ahead is getting started.\" — Mark Twain\nYou've got this!",
            "🌟 \"It always seems impossible until it's done.\" — Nelson Mandela\nKeep pushing!",
            "🔥 \"Don't watch the clock; do what it does. Keep going.\" — Sam Levenson",
            "✨ Every expert was once a beginner.\nYour hard work TODAY builds your success TOMORROW!",
        ]
    },

    # ── Default / Fallback ─────────────────────────────────
    "default": {
        "patterns": [],
        "responses": [
            "Hmm, I'm not sure about that. 🤔 Could you rephrase?",
            "I didn't quite get that. Try asking about courses, exams, time, or college info!",
            "That's a tricky one! I'm still learning. 😅 Ask me about college, coding, or general topics.",
            "I'm not sure I understand. Type 'help' to see what I can do!",
        ]
    },

    # ── Help ───────────────────────────────────────────────
    "help": {
        "patterns": ["help", "commands", "options", "what can you do",
                     "menu", "guide", "topics", "show me"],
        "responses": [
            "📌 **I can help you with:**\n"
            "• 👋 Greetings & small talk\n"
            "• 🕐 Current time & date\n"
            "• 🎓 College: admissions, courses, exams, fees, hostel, placement\n"
            "• 💻 Python & programming tips\n"
            "• 🤖 AI & Machine Learning info\n"
            "• 😂 Jokes & motivation\n"
            "• ❓ General questions\n\n"
            "Just type your question naturally!"
        ]
    },
}


# ============================================================
# NLP ENGINE
# ============================================================

def preprocess(text: str) -> list:
    """
    Tokenize, lowercase, and lemmatize the input text.
    Removes punctuation but keeps meaningful words.

    Args:
        text (str): Raw user input

    Returns:
        list: Cleaned, lemmatized tokens
    """
    try:
        tokens = word_tokenize(text.lower())
        # Keep only alphabetic tokens (removes punctuation and numbers)
        tokens = [lemmatizer.lemmatize(t) for t in tokens if t.isalpha()]
        return tokens
    except Exception:
        # Fallback: simple split if NLTK fails
        return text.lower().split()


def match_intent(user_input: str) -> str:
    """
    Match user input to the best intent using keyword overlap.

    Strategy:
        1. Preprocess input into tokens.
        2. For each intent, count how many pattern words appear in the tokens.
        3. Multi-word phrase matches get a much higher score.
        4. Return the intent with the highest match score.
        5. If no match (score == 0), return 'default'.

    Args:
        user_input (str): The raw message from the user

    Returns:
        str: The matched intent key
    """
    tokens = set(preprocess(user_input))
    raw_lower = user_input.lower().strip()

    best_intent = "default"
    best_score = 0

    for intent, data in INTENTS.items():
        if intent == "default":
            continue

        score = 0
        for pattern in data["patterns"]:
            pattern_lower = pattern.lower()
            # Full phrase exact match — highest priority
            if pattern_lower == raw_lower:
                score += 20
            # Multi-word phrase contained in input
            elif " " in pattern_lower and pattern_lower in raw_lower:
                score += 10
            else:
                # Individual token matching
                pattern_tokens = set(preprocess(pattern))
                overlap = tokens & pattern_tokens
                score += len(overlap) * 2

        if score > best_score:
            best_score = score
            best_intent = intent

    # Only return a match if there's at least some signal
    return best_intent if best_score > 0 else "default"


def generate_response(user_input: str) -> str:
    """
    Main function called by the GUI to get a bot response.

    Steps:
        1. Detect special intents (time / date) with real-time values.
        2. Match the intent.
        3. Pick a random response from the matched intent's list.

    Args:
        user_input (str): Message typed by the user

    Returns:
        str: The chatbot's reply
    """
    if not user_input.strip():
        return "Please type a message! 😊"

    intent = match_intent(user_input)
    responses = INTENTS[intent]["responses"]

    # Pick a random response
    response = random.choice(responses)

    # Replace time/date placeholders with live values
    if response == "__TIME__":
        now = datetime.now()
        response = f"🕐 The current time is **{now.strftime('%I:%M %p')}**"

    elif response == "__DATE__":
        now = datetime.now()
        response = (
            f"📅 Today is **{now.strftime('%A, %d %B %Y')}**\n"
            f"Week {now.strftime('%U')} of {now.year}"
        )

    return response
